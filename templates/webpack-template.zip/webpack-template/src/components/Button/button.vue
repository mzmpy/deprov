<template>
  <button type="button" @click="clicked()">{{ label }}</button>
</template>

<script>
import { defineComponent } from 'vue'

export default defineComponent({
  name: 'eButton',
  props: {
    label: {
      type: String,
      default: 'ClickMe'
    }
  },
  methods: {
    clicked() {
      alert(this.label)
    }
  }
})
</script>

<style>

</style>