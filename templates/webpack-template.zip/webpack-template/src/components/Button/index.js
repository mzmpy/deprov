import button from './button.vue'

export default button
