<template>
  <div class="center">
    <e-button :label="'Hello'"></e-button>
  </div>
</template>

<script>
import eButton from './components/Button'

export default {
  data() {
    return {}
  },
  components: { eButton }
}
</script>

<style>
  .center {
    display: inline-block;
  }
</style>